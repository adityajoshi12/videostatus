<?php

	return [
		'request_constant_record' => 5,
		'related_video_count' => 20,

	];
?>
