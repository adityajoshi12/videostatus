<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Video extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'videos';
    protected $fillable = ['thumbnail','path','size','view','category_id','title','language_id','language','video_of_day','username','email'];

    public function category()
    {
        return $this->belongsTo(Category::class, 'category_id');
    }
}
