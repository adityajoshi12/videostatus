<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Category;

class CategoryController extends Controller
{
    public function index(Request $request)
    {
        $category_data = Category::all();
        return view('category.index',compact('category_data'));
    }

    public function create($id = -1)
    {
        if($id == -1)
        {
            $category_data = new Category;
        }else
        {
            $category_data = Category::where('id',$id)->first();
        }        
        return view('category.create',compact('category_data'));
    }

    public function store(Request $request)
    {   
        // dd($request->all());

        if($request->id == null){        
            $category_data = array(
                "logo"   => $request->logo,
            );
            $validator = \Validator::make($category_data,
            [ 
                'logo'    => 'required|mimes:jpeg,jpg,png,gif|max:10000'                                     // max 10000kb
            ]); 
                
            if($validator->fails()) 
            { 
                foreach($validator->getMessageBag()->toArray() as $error_data){
                    foreach($error_data as $error){
                        $errors[] = ucwords(" ".$error);
                    }
                }
                return redirect()->back()->withErrors($errors);
            }
            $path = public_path().'/category/';
            $filename = str_replace(' ', '', $request->logo->getClientOriginalName());
            $request->logo->move($path, $filename);
            $logo_file = $filename;
        }else{
            if(isset($request->logo)){
                $path = public_path().'/category/';
                $filename = str_replace(' ', '', $request->logo->getClientOriginalName());
                $request->logo->move($path, $filename);
                $logo_file = $filename;
            }else{
                $category_data = Category::where('id',$request->id)->first();
                $logo_file = $category_data->logo;
            }
        }
        $logo_name = '';
        $save_data = array(
            'name' => $request->name,
            'logo' => $logo_file 
        );
        // dd($save_data);

        if($request->id == null){
            Category::create($save_data);
            return redirect()->route('category.index')->withSuccess("Category data has been added successfully.");
        }else{
            Category::where('id',$request->id)->update($save_data);
            return redirect()->route('category.index')->withSuccess("Category data has been updated successfully.");
        }

    }

    public function destroy($id)
    {
        $column_name = "category_id";
        $table_name = "categorys";
        $del_status = CheckRecordExist($column_name,$id,$table_name);
        if($del_status == false){
            return redirect()->back()->withErrors("Sorry, You Can't Delete Because It Is Already Used Somewhere");
        }

        Category::where('id',$id)->delete();
        return redirect()->route('category.index')->withSuccess("Category data has been deleted successfully.");
    }
}
