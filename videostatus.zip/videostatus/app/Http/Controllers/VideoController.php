<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Video;
use App\Language;
use App\Category;
use App\Report;
use App\NotificatonRegister;
use Config;
use DB;

class VideoController extends Controller
{
    public function VideoList(Request $request)
    {
        // dd($request->all());
        $video_data = array();
        $ppr = Config::get('constants.request_constant_record');               // constant record
        $language_id = $request->l_id;
        $category_id = $request->c_id;
        $sort = $request->sort;
        $order_by = $request->order_by;

        $query = '';

        if($language_id != "-1"){
            $query = ' AND v.language_id='.$language_id.'';
        }

        if($category_id != "-1"){
            $query = ' AND v.category_id='.$category_id.'';
        }

        if($sort == "1" OR $order_by== "1")
        {
            $query .= " ORDER BY v.video_of_day DESC, v.id DESC";
        }
        else if($sort == "2" OR $order_by == "0")
        {
            $query .= " ORDER BY v.video_of_day DESC, v.id ASC";
        }
        else if($sort == "3")
        {
            $query .= " ORDER BY v.video_of_day DESC, v.View DESC";
        }
        else if($sort == "4")
        {
            $query .= " ORDER BY v.video_of_day DESC, v.View ASC";
        }
        else if($order_by == "2")
        {
            $query .= " ORDER BY v.video_of_day DESC, RAND()";
        }
        
        $page_index = $request->page;
        if($page_index == 0)
        {
            $start = 0;
            $end = $ppr;
        }else{
            $start = ($ppr * $page_index);
            $end = $ppr ;
        }
        $video_all_data = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v 
                            LEFT JOIN categorys c ON c.id = v.category_id
                            LEFT JOIN languages l ON l.id = v.language_id
                            WHERE v.status = 1 '.$query);
                            // WHERE v.status = 1 '.$query.' LIMIT '.$start.','.$end);

        if(count($video_all_data) != 0)
        {
            foreach($video_all_data as $video)
            {
                $view_count = \App\ViewLike::where('video_id',$video->id)->get();
                $video->view = count($view_count);
                $video->thumbnail = '/videos/image/'.$video->thumbnail;
                $video->path = '/videos/'.$video->path;
                $video_data[] = $video;
            }
        }
        
        $video_data_total = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v 
                            LEFT JOIN categorys c ON c.id = v.category_id
                            LEFT JOIN languages l ON l.id = v.language_id
                            WHERE v.status = 1 '.$query.'');

        return \Response::json([
            'status'  => true,
            'message' => "Video List",
            "count"    => count($video_data_total),
            'data'    => $video_data,
        ]);
    }

    public function SearchList(Request $request)
    {
        $video_data = array();
        $keyword = $request->keyword;
        $videos = DB::select('SELECT id,title FROM `videos` WHERE status = 1');
        if(count($videos) != 0){
            $video_data = $videos;
        }
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            'data'    => $video_data,
        ]);
    }

    public function SearchVideoList(Request $request)
    {
        $video_data = array();
        $keyword = $request->keyword;
        $video_all_data = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v
                                LEFT JOIN categorys c ON c.id = v.category_id
                                LEFT JOIN languages l ON l.id = v.language_id
                                WHERE v.title LIKE \'%'.$keyword.'%\' AND v.status = 1');
        if(count($video_all_data) != 0)
        {
            foreach($video_all_data as $video)
            {
                $view_count = \App\ViewLike::where('video_id',$video->id)->get();
                $video->view = count($view_count);
                $video->thumbnail = '/videos/image/'.$video->thumbnail;
                $video->path = '/videos/'.$video->path;
                $video_data[] = $video;
            }
        }
        
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            'data'    => $video_data,
        ]);
    }

    public function TrendingVideo(Request $request)
    {
        $video_data = array();
        $video_all_data = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v
                        LEFT JOIN categorys c ON c.id = v.category_id
                        LEFT JOIN languages l ON l.id = v.language_id
                        WHERE v.trending=1 AND v.status = 1');
        if(count($video_all_data) != 0)
        {
            foreach($video_all_data as $video)
            {
                $view_count = \App\ViewLike::where('video_id',$video->id)->get();
                $video->view = count($view_count);
                $video->thumbnail = '/videos/image/'.$video->thumbnail;
                $video->path = '/videos/'.$video->path;
                $video_data[] = $video;
            }
        }             
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            'data'    => $video_data,
        ]);
    }

    public function VideoUpload(Request $request)
    {
        $video_details = json_decode($request->upload_data);
        // dd($video_details);
        $video_file = "";
        $img_file = "";
        $msg = '';
        $video_data = array(
            "title" => $video_details->u_video_title,
        );
        // "video" => $request->video_file,
        $validator = \Validator::make($video_data,
        [ 
            'title' => 'required|regex:/^[a-zA-Z]+$/u|max:255',
            
        ]); 
        // 'video' => 'required|mimes:mp4,x-flv,x-mpegURL,MP2T,3gpp,quicktime,x-msvideo,x-ms-wmv',
            
        if($validator->fails()) 
        { 
            foreach($validator->getMessageBag()->toArray() as $error_data){
                foreach($error_data as $error){
                    $msg[] = ucwords(" ".$error);
                }
            }
            return \Response::json([
                'status'  => false,
                'message' => ucwords(implode(',',$msg))
            ]);
        }

        if(isset($request->video_file)){
            $path = public_path().'/videos/';
            $filename = str_replace(' ', '', $request->video_file->getClientOriginalName());
            $request->video_file->move($path, $filename);
            $video_file = $filename;
        }

        if(isset($request->img_file)){
            $path = public_path().'/videos/image';
            $filename = str_replace(' ', '', $request->img_file->getClientOriginalName());
            $request->img_file->move($path, $filename);
            $img_file = $filename;
        }
        
        $language = Language::where('value',$video_details->u_video_language)->first();
        $language_id = '';
        if($language != '')
        {
            $language_id = $language->id;
        }
        $data = array(
            'thumbnail' => $img_file,
            'path' => $video_file,
            'size' => $video_details->u_video_size,
            'title' => $video_details->u_video_title,
            'category_id' => "12",
            'language' => $video_details->u_video_language,
            'language_id' => $language_id,
            'username' => $video_details->u_video_username,
            'email' => $video_details->u_video_email,
        );
        $video_save_data = \App\Video::create($data);

        return \Response::json([
            'status' => true,
            'message' => "Video upload successfully",
        ]);
    }
    

    public function PopularVideoList(Request $request)
    {
        $ppr = Config::get('constants.request_constant_record');               // constant record
        $page_index = $request->page;
        if($page_index == 0)
        {
            $start = 0;
            $end = $ppr;
        }else{
            $start = ($ppr * $page_index);
            $end = $ppr ;
        }
        $video_data = array();

        $video_data_total = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v 
                            LEFT JOIN categorys c ON c.id = v.category_id
                            LEFT JOIN languages l ON l.id = v.language_id
                            WHERE v.status = 1 ORDER BY v.view DESC');
        $video_all_data = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v 
                            LEFT JOIN categorys c ON c.id = v.category_id
                            LEFT JOIN languages l ON l.id = v.language_id
                            WHERE v.status = 1 ORDER BY v.view DESC');
                            // WHERE v.status = 1 ORDER BY v.view DESC LIMIT '.$start.','.$end);
        if(count($video_all_data) != 0)
        {
            foreach($video_all_data as $video)
            {
                $view_count = \App\ViewLike::where('video_id',$video->id)->get();
                $video->view = count($view_count);
                $video->thumbnail = '/videos/image/'.$video->thumbnail;
                $video->path = '/videos/'.$video->path;
                $video_data[] = $video;
            }
        }

        return \Response::json([
            'status'  => true,
            'message' => "Video List",
            "count"    => count($video_data_total),
            'data'    => $video_data,
        ]);
    }

    public function RelatedVideoList(Request $request)
    {
        $video_data = array();
        $rlistcount = Config::get('constants.related_video_count');               // constant record
        $video_all_data = DB::select('SELECT v.*,c.name as category_name, l.value as language_name FROM `videos` v 
                            LEFT JOIN categorys c ON c.id = v.category_id
                            LEFT JOIN languages l ON l.id = v.language_id
                            WHERE v.id != '.$request->v_id.' AND v.status = 1
                            ORDER BY RAND() LIMIT '.$rlistcount);
        if(count($video_all_data) != 0)
        {
            foreach($video_all_data as $video)
            {
                $view_count = \App\ViewLike::where('video_id',$video->id)->get();
                $video->view = count($view_count);
                $video->thumbnail = '/videos/image/'.$video->thumbnail;
                $video->path = '/videos/'.$video->path;
                $video_data[] = $video;
            }
        }
        return \Response::json([
            'status' => true,
            'message' => "Success",
            'data'    => $video_data,
        ]);
    }

    public function Reports(Request $request)
    {
        $data = array(
            'report_v_id' => $request->report_v_id,
            'report_v_content' => $request->report_v_content,
            'report_description' => $request->report_description,
        );
        $v_id = \App\Report::create($data);

        return \Response::json([
            'status' => true,
            'message' => "Success",
        ]);
    }
     
    public function ViewLikeSave(Request $request)
    {
        $view_data = \App\ViewLike::where('video_id',$request->video_id)->where('phone_id',$request->phone_id)->where('type',$request->type)->first();
        if(count($view_data) == 0)
        {
            $save_data = array(
                'video_id' => $request->video_id,
                'phone_id' => $request->phone_id,
                'type' => $request->type,
            );
            \App\ViewLike::create($save_data);
            $video_data = \App\Video::where('id',$request->video_id)->first();
            $total_view = $video_data->view + 1;
            \App\Video::where('id',$request->video_id)->update(array('view'=>$total_view));

            return \Response::json([
                'status' => true,
                'message' => "Success",
            ]);
        }else{
            return \Response::json([
                'status' => false,
                'message' => "Success",
            ]);
        }
    }

    public function RegisterNotificaton(Request $request)
    {
        $check_data = NotificatonRegister::where('register_id', $request->register_id)->where('device_id', $request->device_id)->get();
        if(count($check_data) == 0)
        {
            $save = array(
                'register_id' => $request->register_id,
                'device_id' => $request->device_id,
            );
            \App\NotificatonRegister::create($save);
        }
        return \Response::json([
            'status' => true,
            'message' => "Success",
        ]);
    }
}
