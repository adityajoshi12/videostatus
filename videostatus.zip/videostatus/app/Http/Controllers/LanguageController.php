<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Language;

class LanguageController extends Controller
{
    public function index(Request $request)
    {
        $language_data = Language::all();
        return view('language.index',compact('language_data'));
    }

    public function create($id = -1)
    {
        if($id == -1)
        {
            $language_data = new Language;
        }else
        {
            $language_data = Language::where('id',$id)->first();
        }        
        return view('language.create',compact('language_data'));
    }

    public function store(Request $request)
    {   
        $save_data = array(
            'value' => $request->value,
        );

        if($request->id == null){
            Language::create($save_data);
            return redirect()->route('language.index')->withSuccess("Language data has been added successfully.");
        }else{
            Language::where('id',$request->id)->update($save_data);
            return redirect()->route('language.index')->withSuccess("Language data has been updated successfully.");
        }

    }

    public function destroy($id)
    {
        $column_name = "language_id";
        $table_name = "languages";
        $del_status = CheckRecordExist($column_name,$id,$table_name);
        if($del_status == false){
            return redirect()->back()->withErrors("Sorry, You Can't Delete Because It Is Already Used Somewhere");
        }
        Language::where('id',$id)->delete();
        return redirect()->route('language.index')->withSuccess("Language data has been deleted successfully.");
    }
}
