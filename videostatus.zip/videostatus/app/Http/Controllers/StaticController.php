<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Language;
use App\Category;

class StaticController extends Controller
{
    public function CategoryLanguage(Request $request)
    {
        $language = Language::all();
        $category = Category::all();
        $category_data = array();
        if(count($category) != 0){
            foreach($category as $c){
                $c->logo = '/category/'.$c->logo;
                $category_data[] = $c;
            }
        }
        
        return \Response::json([
            'status'  => true,
            'message' => "Success",
            "language"    => $language,
            'category'    => $category_data,
        ]);
    }

    public function reportindex()
    {
        $report_data = \App\Report::get();
        return view('reports.index',compact('report_data'));
    }

    public function changePWD()
    {
        return view('auth.passwords.changePWD');
    }

    public function changePWDStore(Request $request)
    {
        if($request->password == $request->confirm_pwd)
        {
            $user = \Auth::user();
            $pwd = bcrypt($request->password);
            \App\User::where('id',$user->id)->update(array('password' => $pwd));
            return redirect()->route('change_pwd')->withSuccess("Password Change successfully.");
        }else{
            return redirect()->route('change_pwd')->withErrors("Your password and confirm password done not match. Try Agin.");
        }
    }
}
