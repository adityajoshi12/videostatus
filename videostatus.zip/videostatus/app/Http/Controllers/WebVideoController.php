<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Video;
use App\Language;
use App\Category;
use App\Report;
use Config;
use DB;
use Yajra\Datatables\Datatables;

class WebVideoController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function Videoindex()
    {
        $video_data = Video::all();
        return view('video.index',compact('video_data'));
    }

    // public function videoGetData()
    // {
    //   $videos = Video::select(DB::raw('@rownum := @rownum + 1 AS row_no'),'videos.*');
    //   $videos->get();
    //   DB::statement(DB::raw('set @rownum=0'));

    //   return Datatables::of($videos)
    //         ->editColumn('category_id', function ($videos) {
    //             $category_name= '';
    //             if($videos->category_id != '')
    //             {
    //                 $category = Category::where('id',$videos->category_id)->first();
    //                 $category_name = $category->name;
    //             }
                 
    //             return $category_name;
    //         })
    //         ->addColumn('action', function ($videos) {
    //             return '
    //             <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">Approve</button>
    //             <a href="'.route('video_edit',['id'=>$videos->id]).'"> Edit </a>
    //             <a href="'.route('video_delete',['id'=>$videos->id]).'" Onclick="return video_delete()"> Delete </a>';
    //         })
    //         ->make(true);
    // }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function Videocreate(Request $request)
    {
        // dd($request->all());
        $relation = [
            'category'   => \App\Category::get()->pluck('name', 'id')->prepend('Please select', ''),
            'language'  => \App\Language::get()->pluck('value', 'value')->prepend('Please select', ''),
        ];
        if(isset($request->id)){
            $video_data = Video::where('id',$request->id)->first();
        }else{
            $video_data = new Video;
        }
        return view('video.create',compact('video_data')+$relation);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function Videostore(Request $request)
    {
        // dd($request->all());
        $video_details = $request->all();
        $video_file = "";
        $img_file = "";
        $size = 0;
        
        if($request->id == null){
        
            $video_data = array(
                "title" => $video_details['title'],
                "video" => $request->video_file,
                "img"   => $request->video_img,
            );
            $validator = \Validator::make($video_data,
            [ 
                'title' => 'required|regex:/^[a-zA-Z\s]+$/u|max:255',
                'video' => 'required|mimes:mp4,x-flv,x-mpegURL,MP2T,3gpp,quicktime,x-msvideo,x-ms-wmv',
                'img'    => 'required|mimes:jpeg,jpg,png,gif|max:10000'                                     // max 10000kb
            ]); 
                
        }else{
            $video_data = array(
                "title" => $video_details['title'],
            );
            $validator = \Validator::make($video_data,
            [ 
                'title' => 'required|regex:/^[a-zA-Z\s]+$/u|max:255',
            ]);            
        }
        if($validator->fails()) 
        { 
            foreach($validator->getMessageBag()->toArray() as $error_data){
                foreach($error_data as $error){
                    $errors[] = ucwords(" ".$error);
                }
            }
            // dd($msg);
            return redirect()->back()->withErrors($errors);
        }
        
            
        if(isset($request->video_file)){
            $video_size = $request->video_file->getClientSize();
            $size = $this->filesize_formatted($video_size);
            
            $path = public_path().'/videos/';
            $filename = str_replace(' ', '', $request->video_file->getClientOriginalName());
            $request->video_file->move($path, $filename);
            $video_file = $filename;
        }else{
            $v_data = \App\Video::where('id',$request->id)->first();
            $video_file = $v_data->path;
            $size = $v_data->size;
        }

        if(isset($request->video_img)){
            $path = public_path().'/videos/image';
            $filename = str_replace(' ', '', $request->video_img->getClientOriginalName());
            $request->video_img->move($path, $filename);
            $video_img = $filename;
        }else{
            $v_data = \App\Video::where('id',$request->id)->first();
            $video_img = $v_data->thumbnail;            
        }
        
        $language = Language::where('value',$video_details['language'])->first();
        $language_id = '';
        if($language != '')
        {
            $language_id = $language->id;
        }
        $savedata = array(
            'thumbnail' => $video_img,
            'path' => $video_file,
            'size' => $size,
            'title' => $video_details['title'],
            'category_id' => $video_details['category_id'],
            'language' => $video_details['language'],
            'language_id' => $language_id,
            'username' => $video_details['username'],
            'email' => $video_details['email'],
        );

        if($request->id == null){
            $video_save_data = \App\Video::create($savedata);
            return redirect()->route('video_list')->withSuccess("Video Successfully Saved.");
        }else{
            \App\Video::where('id',$request->id)->update($savedata);
            return redirect()->route('video_list')->withSuccess("Video Data Update Successfully.");
        }
    }

    public function VideoDelete(Request $request)
    {
        Video::where('id',$request->id)->delete();
        return redirect()->route('video_list')->withSuccess("Video Delete Successfully.");
    }

    public function Videoapprove(Request $request)
    {
        $data = Video::where('id',$request->id)->first();
        if($request->name == "status"){
            if($data->status == 0){
                Video::where('id',$request->id)->update(array("status" => 1));
            }else{
                Video::where('id',$request->id)->update(array("status" => 0));
            }
        }else{
            if($data->trending == 0){
                Video::where('id',$request->id)->update(array("trending" => 1));
            }else{
                Video::where('id',$request->id)->update(array("trending" => 0));
            }
        }
        
        if($request->name == "status"){
            if($data->notification == 0){
                $Ndata = array(
                    "type" => 1,
                    "v_id" => $data->id,
                    "v_view" => $data->view,
                    "v_thumbnail" => '/videos/image/'.$data->thumbnail,
                    "v_path" => '/videos/'.$data->path,
                    "v_category" => $data->category->name,
                    "image" => '/videos/image/'.$data->thumbnail,
                    'title' => "New Video",
                    'message' => "Check the New Video",
                );
                $check = sendNotification($Ndata);
                Video::where('id',$request->id)->update(array("notification" => 1));
            }
        }
        
        return response()->json(['status'=>TRUE, 'message'=> ' Successfully.']);
    }

    public function filesize_formatted($bytes)
    {
        if ($bytes >= 1073741824) {
            return number_format($bytes / 1073741824, 2) . ' GB';
        } elseif ($bytes >= 1048576) {
            return number_format($bytes / 1048576, 2) . ' MB';
        } elseif ($bytes >= 1024) {
            return number_format($bytes / 1024, 2) . ' KB';
        } elseif ($bytes > 1) {
            return $bytes . ' bytes';
        } elseif ($bytes == 1) {
            return '1 byte';
        } else {
            return '0 bytes';
        }
    }


    public function Notification(Request $request)
    {
        return view('home.notification');
    }

    public function NotificationSave(Request $request)
    {
        $Ndata = array(
            "type" => 0,
            'title' => $request->title,
            "message" => $request->msg,
        );
        $check = sendNotification($Ndata);
        return redirect()->route('video_list')->withSuccess("Notification Message Send Successfully.");
    }
}
