<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class NotificatonRegister extends Model
{
    protected $primaryKey = 'id';
    protected $table = 'notification_register';
    protected $fillable = ['register_id','device_id'];
}
