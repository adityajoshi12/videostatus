<?php

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| Here you may define all of your model factories. Model factories give
| you a convenient way to create models for testing and seeding your
| database. Just tell the factory how a default model should look.
|
*/

/** @var \Illuminate\Database\Eloquent\Factory $factory */
// $factory->define(App\User::class, function (Faker\Generator $faker) {
//     static $password;

//     return [
//         'name' => $faker->name,
//         'email' => $faker->unique()->safeEmail,
//         'password' => $password ?: $password = bcrypt('secret'),
//         'remember_token' => str_random(10),
//     ];
// });

$factory->define(App\Video::class, function (Faker\Generator $faker) {
    return [
        'thumbnail' => $faker->name,
        'path' => $faker->name,
        'size' => $faker->randomFloat($nbMaxDecimals = NULL, $min = 0, $max = 100),
        'view' => $faker->randomNumber($nbDigits = NULL, $strict = false),
        'category' => $faker->company,
        'title' => $faker->company,
        'language_id' => $faker->randomDigit,
        'video_of_day' => $faker->randomDigit,
    ];
});

