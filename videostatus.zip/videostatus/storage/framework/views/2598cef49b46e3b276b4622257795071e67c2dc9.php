<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Language List 
                    <a href="<?php echo e(route('language.create')); ?>" class="" style="float:right;">Add New</a>
                </div>
                <div class="panel-body">
                    <?php if(Session::has('success')): ?>
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-right"></i> Success
                            </h6>
                            <?php echo e(Session::get('success')); ?>

                        </div>
                    <?php endif; ?>
                    <?php if(count($errors) > 0): ?>
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-ban"></i> Errors
                            </h6>
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    <?php endif; ?>
    
                    <div style="padding-left:20px; padding-right:20px;padding-top:20px;">
                        <div style="padding-bottom:10px;">
                            
                        </div>
                        <table class="table table-bordered table-hover" id="language-table" style="text-align:center;">
                            <?php $i=1 ?>
                            <thead>
                                <tr>
                                    <th style="text-align:center;">Sr No.</th>
                                    <th style="text-align:center;">Language Name</th>
                                    <th style="text-align:center;">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $i = 1; ?>
                                <?php if(count($language_data) != 0): ?>
                                    <?php $__currentLoopData = $language_data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $language): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td style="text-align:center;"><?php echo e($i++); ?></td>
                                        <td style="text-align:center;"><?php echo e($language->value); ?></td>
                                        <td style="text-align:center; width:100px;">                                        
                                            <a href="<?php echo e(route('language.edit',['id'=>$language->id])); ?>" class="btn btn-primary"> Edit </a>
                                            <a href="<?php echo e(route('language.delete',['id'=>$language->id])); ?>" Onclick="return delete_function()" class="btn btn-danger"> Delete </a>    
                                        </td>
                                    </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="3">No Record Found</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
	







<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>