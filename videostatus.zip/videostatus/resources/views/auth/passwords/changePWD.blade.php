@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Change Password 
                </div>
                <div class="panel-body">
                    @if (Session::has('success'))
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-right"></i> Success
                            </h6>
                            {{ Session::get('success') }}
                        </div>
                    @endif
                    @if (count($errors) > 0)
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-ban"></i> Errors
                            </h6>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
    
                    <div class="flex-center position-ref full-height">
                        <div class="content">
                            <form enctype="multipart/form-data" method="post" action="{{route('changePWD.store')}}" files="true" >
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                <div class="form-group">
                                    <label for="password"><b>New Password</b></label>
                                    <input type="password" class="form-control" id="password" name="password" placeholder="New Password" value="" required>
                                </div>
                                <div class="form-group">
                                    <label for="confirm_pwd"><b>Confirm Password</b></label>
                                    <input type="password" class="form-control" id="confirm_pwd" name="confirm_pwd" placeholder="Confirm Password" value="" required>
                                </div>
                                                        
                                <button type="submit" class="btn btn-success">Submit</button>
                                <a href="{{route('home')}}" class="btn btn-primary">Back</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection