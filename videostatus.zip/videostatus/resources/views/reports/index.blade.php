@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Reports List 
                </div>
                <div class="panel-body">
                    @if (Session::has('success'))
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-right"></i> Success
                            </h6>
                            {{ Session::get('success') }}
                        </div>
                    @endif
                    @if (count($errors) > 0)
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-ban"></i> Errors
                            </h6>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
    
                    <div style="padding-left:20px; padding-right:20px;padding-top:20px;">
                        <div style="padding-bottom:10px;">
                            
                        </div>
                        <table class="table table-bordered table-hover" id="category-table" style="text-align:center;">
                            <?php $i=1 ?>
                            <thead>
                                <tr>
                                    <th style="text-align:center;">Sr No.</th>
                                    <th style="text-align:center;">Video Name</th>
                                    <th style="text-align:center;">Video Content</th>
                                    <th style="text-align:center;">Report Description</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $i = 1; ?>
                                @if(count($report_data) != 0)
                                    @foreach($report_data as $report)
                                    <tr>
                                        <td style="text-align:center;">{{$i++}}</td>
                                        <?php $video_data = \App\Video::where('id',$report->report_v_id)->first(); ?>
                                        <td style="text-align:center;">{{ isset($video_data->title) ? $video_data->title : 'Video Deleted'}}</td>
                                        <td style="text-align:center;">{{ $report->report_v_content }}</td>
                                        <td style="text-align:center;">{{ $report->report_description }}</td>                                        
                                    </tr>
                                    @endforeach
                                @else
                                    <tr>
                                        <td colspan="4">No Record Found</td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection