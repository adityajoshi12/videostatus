@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Videos List 
                    <a href="{{route('upload_video')}}" class="" style="float:right;">Add New</a>
                </div>
                <div class="panel-body">
                    @if (Session::has('success'))
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-right"></i> Success
                            </h6>
                            {{ Session::get('success') }}
                        </div>
                    @endif
                    @if (count($errors) > 0)
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-ban"></i> Errors
                            </h6>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
    
                    <div style="padding-left:20px; padding-right:20px;padding-top:20px;">
                        <div style="padding-bottom:10px;">
                            
                        </div>
                        <table class="table table-bordered table-hover" id="video-table" style="text-align:center;">
                            <?php $i=1 ?>
                            <thead>
                                <tr>
                                    <th style="text-align:center;">Sr No.</th>
                                    <th style="text-align:center;">Video Title</th>
                                    <th style="text-align:center;">Category Name</th>
                                    <th style="text-align:center;">Language</th>
                                    <th style="text-align:center;">Video</th>
                                    <th style="text-align:center;">Approve</th>
                                    <th style="text-align:center;">Trending</th>
                                    <th style="text-align:center;">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $i = 1; ?>
                                @if(count($video_data) != 0)
                                    @foreach($video_data as $video)
                                    <tr>
                                        <td style="text-align:center;">{{$i++}}</td>
                                        <td style="text-align:center;">{{$video->title}}</td>
                                        <?php $category_name= 'Other';
                                            if($video->category_id != '')
                                            {
                                                $category = \App\Category::where('id',$video->category_id)->first();
                                                $category_name = isset($category->name) ? $category->name : '';
                                            } 
                                        ?>
                                        <td style="text-align:center;">{{$category_name}}</td>
                                        <td style="text-align:center;">{{$video->language}}</td>
                                        <td style="text-align:center;">
                                            <a class="popup-youtube" href="{{URL::asset('videos')}}<?php echo "/".$video->path ?>" target="_blank">                                    
                                                <img src="{{URL::asset('videos/image')}}<?php echo "/".$video->thumbnail ?>" style="width:60px; height:60px;">
                                            </a>
                                        </td>
                                        <td><input type="checkbox" id="{{$video->id}}" onclick="myFunction(this.id,'status')" {{($video->status == 0) ? '' : "checked" }}></td>
                                        <td><input type="checkbox" id="{{$video->id}}" onclick="myFunction(this.id,'trending')" {{($video->trending == 0) ? '' : "checked" }}></td>
                                        <td style="text-align:center; width:100px;">                                        
                                            <a href="{{route('video_edit',['id'=>$video->id])}}" class="btn btn-primary"> Edit </a>
                                            <a href="{{route('video_delete',['id'=>$video->id])}}" Onclick="return delete_function()" class="btn btn-danger"> Delete </a>    
                                        </td>
                                    </tr>
                                    @endforeach
                                @else
                                    <tr>
                                        <td colspan="8">No Record Found</td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
	






