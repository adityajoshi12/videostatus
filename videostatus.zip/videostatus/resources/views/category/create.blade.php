@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">Add New Category</div>
                <div class="panel-body">
                    @if (Session::has('success'))
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-right"></i> Success
                            </h6>
                            {{ Session::get('success') }}
                        </div>
                    @endif
                    @if (count($errors) > 0)
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-ban"></i> Errors
                            </h6>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
                    <div class="flex-center position-ref full-height">
                        <div class="content">
                            <form enctype="multipart/form-data" method="post" action="{{route('category.store')}}" files="true" >
                                <input type="hidden" name="_token" value="{{ csrf_token() }}">
                                <input type="hidden" name="id" value="{{ $category_data->id }}">
                                <div class="form-group">
                                    <label for="name"><b>Category Name</b></label>
                                    <input type="text" class="form-control" id="name" name="name" placeholder="Category Name" value="{{$category_data->name}}" required>
                                </div>

                                <div class="form-group">
                                    <label for="name"><b>Category Logo</b></label>
                                    <input type="file" class="form-control" id="name" name="logo" placeholder="Category logo" >
                                </div>
                                                      
                                <button type="submit" class="btn btn-success">Submit</button>
                                <a href="{{route('category.index')}}" class="btn btn-primary">Back</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection