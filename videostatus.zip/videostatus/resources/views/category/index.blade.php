@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">
                    Category List 
                    <a href="{{route('category.create')}}" class="" style="float:right;">Add New</a>
                </div>
                <div class="panel-body">
                    @if (Session::has('success'))
                        <div class="alert alert-success alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-right"></i> Success
                            </h6>
                            {{ Session::get('success') }}
                        </div>
                    @endif
                    @if (count($errors) > 0)
                        <div class="alert alert-danger alert-dismissable">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">×</button>
                            <h6>
                                <i class="icon fa fa-ban"></i> Errors
                            </h6>
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </div>
                    @endif
    
                    <div style="padding-left:20px; padding-right:20px;padding-top:20px;">
                        <div style="padding-bottom:10px;">
                            
                        </div>
                        <table class="table table-bordered table-hover" id="category-table" style="text-align:center;">
                            <?php $i=1 ?>
                            <thead>
                                <tr>
                                    <th style="text-align:center;">Sr No.</th>
                                    <th style="text-align:center;">Category Name</th>
                                    <th style="text-align:center;">Category Logo</th>
                                    <th style="text-align:center;">Action</th>
                                </tr>
                            </thead>

                            <tbody>
                                <?php $i = 1; ?>
                                @if(count($category_data) != 0)
                                    @foreach($category_data as $category)
                                    <tr>
                                        <td style="text-align:center;">{{$i++}}</td>
                                        <td style="text-align:center;">{{$category->name}}</td>
                                        <td style="text-align:center;">
                                            <a class="popup-youtube" href="{{URL::asset('category')}}<?php echo "/".$category->logo ?>" target="_blank">                                    
                                                <img src="{{URL::asset('category')}}<?php echo "/".$category->logo ?>" style="width:60px; height:60px;">
                                            </a>
                                        </td>
                                        <td style="text-align:center; width:100px;">                                        
                                            <a href="{{route('category.edit',['id'=>$category->id])}}" class="btn btn-primary"> Edit </a>
                                            <a href="{{route('category.delete',['id'=>$category->id])}}" Onclick="return delete_function()" class="btn btn-danger"> Delete </a>    
                                        </td>
                                    </tr>
                                    @endforeach
                                @else
                                    <tr>
                                        <td colspan="4">No Record Found</td>
                                    </tr>
                                @endif
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
	






