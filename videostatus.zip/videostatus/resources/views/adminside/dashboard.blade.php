@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row">
        <div class="col-md-12 ">
            <div class="panel panel-default">
                <div class="panel-heading">Admin</div>

                <div class="panel-body">
                    @if (session('status'))
                        <div class="alert alert-success">
                            {{ session('status') }}
                        </div>
                    @endif
                    <a href="{{route('upload_video')}}" class="btn btn-primary">Upload Video</a>
                    <a href="{{route('video_list')}}" class="btn btn-success">Videos List</a>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
