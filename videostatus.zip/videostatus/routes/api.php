<?php

use Illuminate\Http\Request;

/*
|--------------------------------------------------------------------------
| API Routes
|--------------------------------------------------------------------------
|
| Here is where you can register API routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| is assigned the "api" middleware group. Enjoy building your API!
|
*/

Route::middleware('auth:api')->get('/user', function (Request $request) {
    return $request->user();
});

Route::any('/video-list','VideoController@VideoList');

Route::any('/category-lang','StaticController@CategoryLanguage');

Route::any('/search-list','VideoController@SearchList');
Route::any('/search-video','VideoController@SearchVideoList');

Route::any('/trending-video','VideoController@TrendingVideo');

Route::any('/video-upload','VideoController@VideoUpload');

Route::any('/popular-video','VideoController@PopularVideoList');

Route::any('/related-video','VideoController@RelatedVideoList');

Route::any('/reports','VideoController@Reports');

Route::any('/save-viewlike','VideoController@ViewLikeSave');

Route::any('/register-notificaton','VideoController@RegisterNotificaton');

